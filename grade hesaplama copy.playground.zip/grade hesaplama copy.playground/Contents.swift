import UIKit

// İki not tanımlaması
let not1 = 90
let not2 = 97

// Ortalamayı hesapla
let ortalama = (not1 + not2) / 2

// Karar yapısı
if ortalama >= 50 {
    print("Geçtiniz. Ortalamanız: \(ortalama)")
} else {
    print("Kaldınız. Ortalamanız: \(ortalama)")
}

